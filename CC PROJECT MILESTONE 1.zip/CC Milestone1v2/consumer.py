import json
from google.cloud import pubsub_v1

# Set the project ID and subscription name
project_id = 'sodium-sublime-448820-j1'
subscription_name = f'projects/{project_id}/subscriptions/labels-subscription'

# Initialize the Pub/Sub Subscriber client
subscriber = pubsub_v1.SubscriberClient()

# Function to handle incoming messages
def callback(message):
    # Deserialize the message
    message_dict = json.loads(message.data.decode('utf-8'))
    
    # Print the values of the message
    print(f"Received message: {message_dict}")
    
    # Acknowledge the message so that it's removed from the subscription queue
    message.ack()

# Subscribe to the topic and listen for messages
def listen_for_messages():
    subscriber.subscribe(subscription_name, callback=callback)
    print(f'Listening for messages on {subscription_name}...')
    
    # Keep the main thread alive to listen for messages
    try:
        while True:
            pass
    except KeyboardInterrupt:
        print('Stopped listening for messages.')

# Run the listen function
listen_for_messages()
