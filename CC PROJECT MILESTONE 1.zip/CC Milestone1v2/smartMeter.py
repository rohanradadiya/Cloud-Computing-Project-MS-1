from google.cloud import pubsub_v1
import json
import random
import time

# Set the project ID
project_id = "sodium-sublime-448820-j1"

# Define random distribution parameters
min_measurement = 50  # Minimum measurement value (e.g., temperature, voltage)
max_measurement = 200  # Maximum measurement value (e.g., temperature, voltage)

# Initialize publisher
publisher = pubsub_v1.PublisherClient()
topic_name = 'projects/{}/topics/smartMeter'.format(project_id)

# Loop to generate and publish 10 random measurements (you can adjust the number)
for _ in range(10):  # Adjust the number of messages to publish
    # Generate random smart meter data
    measurement = {
        'device_id': f'device_{random.randint(1, 100)}',  # Random device ID
        'measurement': random.randint(min_measurement, max_measurement),  # Random measurement (e.g., temperature)
        'timestamp': time.time()  # Timestamp of the measurement
    }

    # Serialize message to JSON
    message_json = json.dumps(measurement)

    # Publish the message to the smartMeter topic
    publisher.publish(topic_name, message_json.encode('utf-8'))

    print(f"Published message: {measurement}")

    # Sleep for 1 second before generating the next measurement
    time.sleep(1)
