import csv
import json
import google.cloud.pubsub_v1 as pubsub_v1
import time

# Initialize Pub/Sub publisher client
publisher = pubsub_v1.PublisherClient()

# Topic you created
topic_name = "projects/sodium-sublime-448820-j1/topics/labels-topic"

def publish_messages():
    try:
        # Read the CSV file
        with open('Labels.csv', mode='r') as file:
            reader = csv.DictReader(file)

            # Print column names for debugging
            print("CSV Columns:", reader.fieldnames)

            for row in reader:
                # Print the row data to understand its structure
                print("Row Data:", row)

                # Adjust these keys based on your actual CSV columns
                message = {
                    'id': row.get('id', 'N/A'),  # Use .get() to avoid KeyError
                    'name': row.get('name', 'N/A'),  # Use .get() to avoid KeyError
                    'value': row.get('value', 'N/A'),  # Use .get() to avoid KeyError
                }

                # Serialize the dictionary into a message (convert it to JSON)
                message_data = json.dumps(message).encode('utf-8')

                # Publish the message and ensure it is published before moving on
                future = publisher.publish(topic_name, message_data)
                future.result()  # Wait for the publish to complete

                print(f"Published message: {message}")

    except Exception as e:
        print(f"An error occurred: {e}")

# Call the publish function
publish_messages()
